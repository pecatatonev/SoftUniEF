﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-DU65TFH;Database=Boardgames;Integrated Security=True";
    }
}
