﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-DU65TFH;Database=MusicHub;Trusted_Connection=True";
    }
}
