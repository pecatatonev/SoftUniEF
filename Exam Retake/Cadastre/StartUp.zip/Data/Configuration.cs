﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-DU65TFH;Database=Cadastre;Integrated Security=True;Encrypt=False";
    }
}
