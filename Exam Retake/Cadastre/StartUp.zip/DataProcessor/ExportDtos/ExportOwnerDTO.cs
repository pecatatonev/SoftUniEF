﻿using Cadastre.Data.Enumerations;

namespace Cadastre.DataProcessor.ExportDtos
{
    public class ExportOwnerDTO
    {
        public string LastName { get; set; }
        public MaritalStatus MaritalStatus { get; set; }
    }
}