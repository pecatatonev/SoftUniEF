﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-DU65TFH;Database=CarDealer;Integrated Security=True;Encrypt=False";
    }
}
