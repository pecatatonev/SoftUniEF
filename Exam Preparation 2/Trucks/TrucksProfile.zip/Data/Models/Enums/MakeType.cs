﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trucks.Data.Models.Enums
{
    public enum MakeType
    {
        Daf, 
        Man,
        Mercedes,
        Scania,
        Volvo
    }
}
