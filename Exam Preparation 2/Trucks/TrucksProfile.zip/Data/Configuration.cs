﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-DU65TFH;Database=Trucks;Trusted_Connection=True";
    }
}